import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu } from 'antd';
import { PieChartOutlined, TeamOutlined, ProfileOutlined,LogoutOutlined  } from '@ant-design/icons';
import { Outlet } from 'react-router-dom';

function Nav() {
  const navigate = useNavigate();

  const Admin = () => navigate('/Admin');
  const dashboard = () => navigate('/dashboard');
  const employee = () => navigate('/employee');
  const dealer = () => navigate('/dealer');
  const logout=()=>{
    localStorage.removeItem("userdata");
    navigate('/login');

  }

  const items = [
    {
      label: 'Dashboard',
      key: 'dashboard',
      icon: <PieChartOutlined style={{ color: '#ffffff' }} />,
      onClick: dashboard,
  
    },
    {
      label: 'User Management',
      key: 'management',
      icon: <TeamOutlined style={{ color: '#ffffff' }} />,
      style: { color: '#ffffff' },
      children: [
        {
          type: 'group',
          label: 'Item 1',
          children: [
            {
              label: 'Admin',
              key: 'setting:1',
              onClick: Admin,
              style: { color: '#ffffff' }
            },
            {
              label: 'Employee',
              key: 'setting:2',
              onClick: employee,
              style: { color: '#ffffff' }
            },
            {
              label: 'Dealer',
              key: 'setting:3',
              onClick: dealer,
              
            },
          ],
        },
      ],
    },
    {
      label: 'Lead',
      key: 'lead',
      icon: <ProfileOutlined style={{ color: '#ffffff' }} />,
      
    },
    {
      label: 'Logout',
      key: 'dashboard',
      icon:<LogoutOutlined style={{ color: '#ffffff' }}  />,
      onClick: logout,
  
    },
  ];

  const [current, setCurrent] = useState('mail');

  const onClick = (e) => {
    console.log('click ', e);
    setCurrent(e.key);
  };

  return (
    <>
      <Menu
        onClick={onClick}
        selectedKeys={[current]}
        mode="horizontal"
        items={items}
        style={{ backgroundColor: '#000',   color: 'white' }}
        theme="dark"
      />
      <Outlet />
    </>
  );
}

export default Nav;
