import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Adminsss, handledelete} from '../../../axios/Services';
import classes from '../User_Management/Login.module.css';
import { Table, Row } from 'antd';
import { handleaddmodal, handlemodal, handleuserid,handledealerid, handleuserType } from '../../../redux/reducers/AuthReducers';
import DeleteModal from '../Modals/DeleteModal';
import AddNew from '../Modals/AddNew';
import { viewuser } from '../../../axios/Services';
import { handleditmodal } from '../../../redux/reducers/AuthReducers';
import UpdateModal from '../Modals/UpdateModal';



function Employee() {
    const token = useSelector((state) => state.auth.token);
    const modal=useSelector((state)=> state.auth.modal);
   const User_Id=useSelector((state)=> state.auth.userid);
   const addnew=useSelector((state)=>state.auth.addmodal);
   const editu=useSelector((state)=> state.auth.editmodal)
    const dispatch=useDispatch();
    const [dta, setDta] = useState([]);
    const [userdata,setData]=useState([]);



    const handleAdd = () => {
    dispatch(handleaddmodal(true));
    dispatch(handleuserType('4'));
    };

   

   
    const handlesub = () => {
        let formData = new FormData();
        formData.append('token', token);
        formData.append('type', '4');
        Adminsss(1, 10, formData)
            .then((res) => {
                setDta(res.data.data.items);

            })
            .catch((error) => {
                console.error('Error response:', error.response ? error.response.data : error.message);
            });
    };
    const edit=(valuess)=>{
    
        const formData = new FormData();
        formData.append("token", token);
        formData.append('userId',valuess);
        viewuser(formData).then((res)=>{
          setData(res.data.data);

        })
       dispatch(handleditmodal(true));
       console.log(editu);
    }

    

    useEffect(() => {
        if (token) {
            handlesub();
        }
    }, [token]);

    const deleteddd = (value) => {
        dispatch(handlemodal(true));
        dispatch(handleuserid(value));
    }
    



    const columns = [
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: 'Username',
            dataIndex: 'userName',
            key: 'userName',
        },
        {
            title: 'Phone Number',
            dataIndex: 'phoneNumber',
            key: 'phoneNumber',
        },
        {
            title: 'User ID',
            dataIndex: 'userId',
            key: 'userId',
        },
        {
            title: 'Action',
            key: 'action',
            render: (text, record) => (
                <button
                    type="button"
                    className={`btn btn-primary ${classes.btnnnn}`}
                    onClick={() => deleteddd(record.userId)} 
                >
                    Delete
                </button>
            ),
        },
        {
            title: 'Action',
            key: 'action',
            render: (text, record) => (
                <button
                    type="button"
                    className={`btn btn-primary ${classes.btnnnnn}`}
                    onClick={() => edit(record.userId)} 
                >
                    edit
                </button>
            ),
        }
    ];

    const dataSource = dta.map((ele) => ({
        name: ele.name,
        userName: ele.userName,
        phoneNumber: ele.phoneNumber,
        userId: ele.userId,
    }));

    return (
        <>
            <Table dataSource={dataSource} columns={columns} rowKey="userId" className="mt-5 ms-5 me-5"/>
            <Row className="row float-end mt-5 me-5">
                <button type="button" className={`btn btn-primary ${classes.btnnnn}`} onClick={handleAdd}>
                    Add New
                </button>
            </Row>

           
            {addnew && (
                
                <AddNew  onclose={()=>{
     dispatch(handleaddmodal(false));
         }} addnew handlesub={handlesub} />)}



         {modal &&(<DeleteModal msg={"Are you sure to delete the User_Id: "} onclose={()=>{
     dispatch(handlemodal(false));
         }}  userId={User_Id}  handledelete={()=>{
            const formData = new FormData();
            formData.append("token", token);
            formData.append('userId',User_Id);
            handledelete(formData).then(() => {
                console.log('Deleted successfully');
                dispatch(handlemodal(false));
                handlesub();
            });
         }} modal/>)} 

{editu && (
    <UpdateModal userdata={userdata} onclose={()=>{
        dispatch(handleditmodal(false));
            }} editu handlesub={handlesub} />
)}

        </>
    );
}

export default Employee;
