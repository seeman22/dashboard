import React, { useDebugValue, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

import classes from '../Login/Login.module.css';
import { Loginpd } from '../../axios/Services';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { handletoken } from '../../redux/reducers/AuthReducers';
import { Row, Col, Checkbox,Button } from 'antd';


function Login() {
  const [pwd, setPwd] = useState('');
    const [input, setInput] = useState('');
    var sha1 = require('sha1');
    const navigate=useNavigate();
    const dispatch=useDispatch();
  

    const handleSubmit = () => {
    
      const formData=new FormData()
      formData.append("userName",input)
      formData.append("password",pwd)
      formData.append("device_type","3")
        formData.append("authcode",sha1("lkjfjIHJL@fdj385!jhg"+input))
    
        Loginpd(formData)
        .then((response) => {
          localStorage.setItem("userdata", JSON.stringify(response.data.token));
            console.log(response.data);
            dispatch(handletoken(response.data.token));

            console.log("successful");
            navigate('/dashboard');
        })
        .catch((error) => {
            console.error('Error fetching users:', error);
        });
   
      
    }
  return (
    <>
       <Row className={`img-fluid ${classes.back}`} justify="center">
      <Col className='col-lg-12 col-md-12 mt-5 d-flex align-items-center'>
        <div className='card w-50 mx-auto'>
          <h1 className='text-center mt-3'>Login</h1>
          <Row justify="center">
            <Col span={24}>
              <label>Username:</label>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className='form-control w-50 mx-auto'
              />
            </Col>
          </Row>
          <Row justify="center">
            <Col span={24}>
              <label>Password:</label>
              <input
                type="password"
                value={pwd}
                onChange={(e) => setPwd(e.target.value)}
                className='form-control w-50 mx-auto'
              />
            </Col>
          </Row>
          <Row justify="space-between" className="ms-5 me-5">
            <Col span={12} style={{ textAlign: 'right' }}>
              <Checkbox />
            </Col>
            <Col span={12} style={{ textAlign: 'left' }}>
              <p>Remember me</p>
            </Col>
          </Row>

       
       <Button type="primary" danger
            className="mb-2 mx-auto d-block"
            onClick={handleSubmit}
          >
            Submit
          </Button>
          <a style={{color:'red'}}onClick={() => { navigate('/signup'); }} className="text-center d-block" >
            Forgot password?
          </a>
        </div>
      </Col>
    </Row>
    </>
  );

}

export default Login;
