import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { Button, Form, Input, Row, Col } from 'antd';
import { resetpassword } from '../../axios/Services';
import { handleresetkey } from '../../redux/reducers/AuthReducers';
import classes from '../Login/Login.module.css';
import verify from '../../assests/Screenshot_2024-09-05_133932-removebg-preview.png';
import { Image } from 'antd';

function ResetPassword() {
    const reset = useSelector((state) => state.auth.resetkey);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    // Validation schema with confirm password field
    const validationSchema = Yup.object({
        changepassword: Yup.string().required('Enter the new password'),
        confirmpassword: Yup.string()
            .oneOf([Yup.ref('changepassword'), null], 'Passwords must match')
            .required('Confirm your password'),
    });

    const { handleSubmit, handleChange, handleBlur, values, errors, touched } = useFormik({
        initialValues: {
            changepassword: '',
            confirmpassword: '',
        },
        validationSchema: validationSchema,
        onSubmit: (values) => handleresetpassword(values),
    });

    const handleresetpassword = (values) => {
        let formData = new FormData();
        formData.append("resetKey", reset);
        formData.append("newPassword", values.changepassword);

        resetpassword(formData).then((res) => {
            console.log(res);
            console.log("Password successfully changed");
        });

        navigate('/login');
    };

    return (
        <Row
            className={`bg-light ${classes.back}`}
            style={{ height: '100vh' }}
            justify="center"
            align="middle"
        >
            <Col xs={24} sm={16} md={8}>
                <Form onFinish={handleSubmit} className="mx-auto p-4" style={{ background: '#fff', borderRadius: '8px' }}>

                <h3 > ResetPassword </h3>
            <Image
    width={200}
    height={150}
    src={verify}
    className='mb-4'
  />
                    <Form.Item
                        label="New Password"
                        validateStatus={touched.changepassword && errors.changepassword ? 'error' : ''}
                        help={touched.changepassword && errors.changepassword ? errors.changepassword : ''}
                        className='p-2'
                    >
                        <Input.Password
                            name="changepassword"
                            value={values.changepassword}
                            onChange={handleChange}
                            onBlur={handleBlur}
                        />
                    </Form.Item>

                    <Form.Item
                        label="Confirm Password"
                        validateStatus={touched.confirmpassword && errors.confirmpassword ? 'error' : ''}
                        help={touched.confirmpassword && errors.confirmpassword ? errors.confirmpassword : ''}
                    >
                        <Input.Password
                            name="confirmpassword"
                            value={values.confirmpassword}
                            onChange={handleChange}
                            onBlur={handleBlur}
                        />
                    </Form.Item>

                    <Button className="btn btn-danger mb-2 w-25" type="primary" htmlType="submit">
                        Submit
                    </Button>
                </Form>
            </Col>
        </Row>
    );
}

export default ResetPassword;
