import { Button, Form, Input, Row, Col } from 'antd';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { forgotpassword } from '../../axios/Services';
import { useDispatch } from 'react-redux';
import { handleresetkey } from '../../redux/reducers/AuthReducers';
import { useNavigate } from 'react-router-dom';
import classes from '../Login/Login.module.css';
import { Image } from 'antd';
import forgetpass from '../../assests/Screenshot 2024-09-05 114454.png';


function Signup() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const validationSchema = Yup.object({
        email: Yup.string().email('Invalid email format').required('Enter the email'),
    });

    const { handleSubmit, handleChange, handleBlur, values, errors, touched } = useFormik({
        initialValues: {
            email: '',
        },
        validationSchema: validationSchema,
        onSubmit: (values) => handlesign(values),
    });

    const handlesign = (values) => {
        let formData = new FormData();
        formData.append("email", values.email);
        forgotpassword(formData).then((res) => {
            const resetKey = res.data.reset_key; 
            console.log("key", res); 
            dispatch(handleresetkey(resetKey)); 
            navigate('/verifyotp');
        });
    };

    return (
        <Row
            className={`bg-light ${classes.back}`}
            style={{ height: '100vh' }}
            justify="center"
            align="middle"
        >
            <Col xs={24} sm={16} md={8}>
      
                <Form onFinish={handleSubmit} className="mx-auto p-5 g-3" style={{ background: '#fff', borderRadius: '8px' }}>
                <h3>Forgot Password</h3>

                <Image
    width={200}
    src={forgetpass}
    className='mb-5'
  />
                    <Form.Item
                        label="Email"
                        validateStatus={touched.email && errors.email ? 'error' : ''}
                        help={touched.email && errors.email ? errors.email : ''}
                 
                    >
                        <Input
                            name="email"
                            value={values.email}
                            onChange={handleChange}
                            onBlur={handleBlur}
                        />
                    </Form.Item>
                    <Button className="btn btn-danger mb-2 w-25" type="primary" htmlType="submit">Submit</Button>
                </Form>
            </Col>
        </Row>
    );
}

export default Signup;

