import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { Button, Form, Input, Row, Col } from 'antd';
import { verifyotp } from '../../axios/Services';
import { handleresetkey } from '../../redux/reducers/AuthReducers';
import classes from '../Login/Login.module.css';
import verify from '../../assests/WhatsApp_Image_2024-09-05_at_12.30.47-removebg-preview.png';
import { Image } from 'antd';

function VerifyOtp() {
    const reset = useSelector((state) => state.auth.resetkey);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    
    const validationSchema = Yup.object({
        otp: Yup.string().required('Enter the OTP'),
    });

    const { handleSubmit, handleChange, handleBlur, values, errors, touched } = useFormik({
        initialValues: {
            otp: '',
        },
        validationSchema: validationSchema,
        onSubmit: (values) => handleverifyotp(values),
    });

    const handleverifyotp = (values) => {
        let formData = new FormData();
        formData.append("resetKey", reset);
        formData.append("otp", values.otp);
        
        verifyotp(formData).then((res) => {
            const resetKey = res.data.reset_key;
            dispatch(handleresetkey(resetKey));
            navigate('/resetpassword');
        });
    };

    return (
        <Row
            className={`bg-light ${classes.back}`}
            style={{ height: '100vh' }}
            justify="center"
            align="middle"
        >
            <Col xs={24} sm={16} md={8}>
                    <Form onFinish={handleSubmit} className="mx-auto p-4" style={{ background: '#fff', borderRadius: '8px' }}>
                    <h3 >Verify OTP </h3>
            <Image
    width={300}
    height={250}
    src={verify}
    className='mb-5'
  />
     
                    <Form.Item
                        label="OTP"
                        validateStatus={touched.otp && errors.otp ? 'error' : ''}
                        help={touched.otp && errors.otp ? errors.otp : ''}
                    >
                        <Input
                            name="otp"
                            value={values.otp}
                            onChange={handleChange}
                            onBlur={handleBlur}
                        />
                    </Form.Item>

                    <Button className="btn btn-danger mb-2 w-25" type="primary" htmlType="submit">
                        Submit
                    </Button>
                </Form>
            </Col>
        </Row>
    );
}

export default VerifyOtp;
