import instance from "./Axios";
import axios from "./Axios";

export const Loginpd = (loginid)=>{
    return axios.post("/login",loginid);
}

export const dashboard = (productid) => {
    return axios.post('dashboard/all_data_count', productid)
}

export const Adminsss=(page,size,data)=>{
    return axios.post(`/user/list_users?page=${page}&size=${size}`,data)
}

export const newadminsadd=(data)=>{
    return axios.post('/user/create_user',data)
}

export const handledelete=(data)=>{
    return axios.post('/user/delete_user',data)
}

export const viewuser=(data)=>{
    return axios.post('/user/view_user',data)
}

export const update=(data)=>{
    return axios.post('/user/update_user',data);
}
export const dropdown=(data)=>{
    return axios.post('/dropdown/employeeDropDown',data);
}

export const forgotpassword=(email)=>{
    return axios.post('/forgotPassword',email)
}

export const verifyotp=(data)=>{
    return axios.post('/verify_otp',data)
}

export const resetpassword=(data)=>{
    return axios.post('/reset_password',data)
}